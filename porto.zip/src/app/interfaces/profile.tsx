export interface InterfaceProfile {
    name: string;
    title: string;
    description: string;
    email: string;
    image: string;
}

